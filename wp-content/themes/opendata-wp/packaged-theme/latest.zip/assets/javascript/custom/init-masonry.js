jQuery(window).load(function(){
  jQuery('.masonry-grid').masonry({
    itemSelector: '.grid-item',
  });
});
